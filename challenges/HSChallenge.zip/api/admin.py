from django.contrib import admin
from .models import data 

admin.site.register(data)
