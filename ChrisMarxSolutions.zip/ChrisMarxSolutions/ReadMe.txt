I have used WAMP server in conjunction with the source code files for solution 1 and solution 2. I have also hosted the site for these solutions from my local machine...
You are welcome to access the site at http://66.25.43.202 for my implementation of the reCaptcha problem. 
And call POST, GET, and PATCH calls against http://66.25.43.202/data for the RESTful problem.
Of course that assumes my ISP doesn't reassign my IP address.